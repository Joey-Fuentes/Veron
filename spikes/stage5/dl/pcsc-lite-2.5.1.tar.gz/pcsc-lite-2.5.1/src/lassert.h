/*
 * Copyright (C) 2007
 *  Jacob Berkman
 * Copyright (C) 2008-2014
 *  Ludovic Rousseau <ludovic.rousseau@free.fr>
 *
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef LASSERT_H
#define LASSERT_H

#include <stdio.h>
#include <stdlib.h>

#if 0
#define FAIL exit (1)
#else
#define FAIL return 1
#endif

#define LASSERT(cond)                                                   \
    ({                                                                  \
        if (! (cond))                                                     \
        {                                                               \
            fprintf (stderr, "%s:%d: assertion FAILED: " #cond "\n",    \
                     __FILE__, __LINE__);                               \
            FAIL;                                                       \
        }                                                               \
    })

#define LASSERTF(cond, fmt, a...)                                       \
    ({                                                                  \
        if (! (cond))                                                     \
        {                                                               \
            fprintf (stderr, "%s:%d: assertion FAILED: " #cond ": " fmt, \
                     __FILE__, __LINE__, ## a);                         \
            FAIL;                                                       \
        }                                                               \
    })

#endif /* LASSERT_H */
